Building Humanscoin
================

See doc/build-*.md for instructions on building the various
elements of the Humanscoin Core reference implementation of Humanscoin.
